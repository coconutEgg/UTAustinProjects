//Required by Instruction
//05-02-2020
#define PROT_WRITE 0x02
#define MAP_ANONYMOUS 0x04
#define MAP_FILE 0x08