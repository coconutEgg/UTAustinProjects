#!/bin/bash
sleep 4
cd tests/p2a-test
ls
