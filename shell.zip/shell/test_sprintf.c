#include <string.h>
#include <stdio.h>
int main()
{
  char sentence []="hellohello.shh";
  printf("%ld",strlen(sentence));
  char str [20];
  char str2[20]={0};
  int i;

  int ok = sscanf (sentence,"%s%*[.sh]%s",str,str2);
  printf("%s\n",str);
  printf("%s\n",str2);
  if(ok!=EOF)
  { 
    
      printf("OK");
  }
  else
  {
      printf("NO OK");
  }
  
  return 0;
    
    
    
}